#ifndef TERRENO_H
#define TERRENO_H


// STRUCT Pessoa(nome, idade)

// STRUCT Terreno(latitude, longitude, area_m2, proprietario)


#endif
